import hashlib

import flask
from flask import url_for  # 进行网页跳转

import os  # 用于操作系统文件的依赖库
import re  # 引入正则表达式对用户输入进行限制
import pymysql  # 连接数据库

# 初始化
app = flask.Flask(__name__)
# 初始化数据库连接
# 使用pymysql.connect方法连接本地mysql数据库
db = pymysql.connect(host='127.0.0.1', port=3306, user='dawn',
                     password='123qweasd', database='db4', charset='utf8')
# 增加session会话保护(任意字符串,用来对session进行加密)
app.secret_key = '123qweasd'
# 操作数据库，获取db下的cursor对象
cursor = db.cursor()
# 存储登陆用户的名字用户其它网页的显示
users = []
resetname=[]

@app.route("/", methods=["GET", "POST"])
def login():
    # 增加会话保护机制(未登陆前login的session值为空)
    msg=''
    flask.session['login'] = ''
    if flask.request.method == 'POST' :
        print(flask.request.method )
        if flask.request.form.get('find')=="findCrpto" :
            #print(flask.request.form.get('find'))
            turn_to='findCrpto'
            return flask.redirect(flask.url_for(turn_to))
        if flask.request.form.get('sign_in')=="sign_in":
            user = flask.request.values.get("user", "")
            pwd = flask.request.values.get("pwd", "")
            user_type = flask.request.values.get("user_type", "")

            print("pwd =",repr(pwd))

        # 对输入的密码进行哈希,用16进制存储
            pwd_hash = hashlib.md5(pwd.encode('UTF-8')).hexdigest()

        # 防止sql注入,如:select * from admins where admin_name = '' or 1=1 -- and password='';
        # 利用正则表达式进行输入判断
            result_user = re.search(r"^[a-zA-Z]+$", user)  # 限制用户名为全字母
            result_pwd = re.search(r"^[a-zA-Z\d]+$", pwd)  # 限制密码为 字母和数字的组合
            if result_user != None and result_pwd != None:  # 验证通过
            # admin为初始管理员，默认密码123qweasd,不需要对此密码加密
                if(user != 'admin'):
                    sql = "select * from admins where admin_name='" + user + "'and admin_password='" + pwd_hash + "';"
                #print("login sql = ",sql)
                else:# 正则验证通过后与数据库中数据进行比较
                    sql = "select * from admins where admin_name='" + user + "' and admin_password='" + pwd + "';"
                cursor.execute(sql)
            #print("cursor = ",cursor)
                result = cursor.fetchone()
            #print("rsult = ",result)
            # 匹配得到结果即管理员数据库中存在此管理员
                if result and result[2] == user_type:
                    print("登陆成功")
                # 登陆成功
                    flask.session['login'] = 'OK'
                    users.append(user)  # 存储登陆成功的用户名用于显示
                    if user_type == '学生':
                        turn_to = 'grade_infos'
                    elif user_type == '教师':
                        turn_to = 'teacher'
                    elif user_type == '管理员':
                        turn_to = 'adminstator'
                    return flask.redirect(flask.url_for(turn_to))
                    # return flask.redirect('/file')
                else :
                    msg = '用户名或密码或身份错误'
            else:  # 输入验证不通过
                msg = '非法输入'
        else:
            msg = ''
            user = ''
    return flask.render_template('login.html',msg=msg)


@app.route("/findCrpto", methods=["GET", "POST"])
def findCrpto():
    # 增加会话保护机制(未登陆前login的session值为空)
    flask.session['login'] = ''
    if flask.request.method == 'POST':
        user = flask.request.values.get("user", "")
        print('resetname_1=',resetname)
        user_type = flask.request.values.get("user_type", "")

        #print("pwd =",repr(pwd))

        # 对输入的密码进行哈希,用16进制存储
        result_user = re.search(r"^[a-zA-Z]+$", user)  # 限制用户名为全字母

        if result_user != None:  # 验证通过
            sql = "select * from admins where admin_name='" + user + "';"
            resetname.append(user)
            cursor.execute(sql)
            #print("cursor = ",cursor)
            result = cursor.fetchone()
            #print("rsult = ",result)
            # 匹配得到结果即管理员数据库中存在此管理员
            if result and result[2] == user_type:
                print("existing user")
                #users.append(resetname)  # 存储登陆成功的用户名用于显示
                turn_to = 'resetcrpto'
                return flask.redirect(flask.url_for(turn_to))
                # return flask.redirect('/file')
            else :
                msg = 'not exist the user name'
        else:  # 输入验证不通过
            msg = '非法输入'
    else:
        msg = ''
        user = ''
    return flask.render_template('findCrpto.html',msg=msg)

@app.route("/resetcrpto", methods=["GET", "POST"])
def resetcrpto():
    flask.session['login'] = ''
    msg=''
    if flask.request.method == 'POST':

        admin_password = flask.request.values.get("admin_password", "")
        print("admin_password =",repr(admin_password))
        admin_password_result = re.search(r"^[a-zA-Z\d]+$", admin_password)  # 限制密码为 字母和数字的组合
        # 验证通过
        if admin_password_result != None:  # 验证通过
            # 获取下拉框的数据
            admin_password_hash = hashlib.md5(admin_password.encode('UTF-8')).hexdigest() #对用户密码md5加密
            print(admin_password_hash)
            try:
                sql_alter = "update admins set admin_password=%s where admin_name=%s;"
                #print('resetname=',resetname.pop())
                rename=resetname.pop()
                print('rename=',rename)
                cursor.execute(sql_alter, (admin_password_hash, rename))
                db.commit()
                turn_to = 'login'
                return flask.redirect(flask.url_for(turn_to))
            except Exception as err:
                print(err)
                msg = "reset failed!"
                pass
        else:  # 输入验证不通过
            msg = "输入的格式或用户不符合要求!"
    else:
        msg = ''
        user = ''
    return flask.render_template('resetcrpto.html',msg=msg)


@app.route('/student', methods=['GET', "POST"])
def student():
    # login session值
    if flask.session.get("login", "") == '':
        # 用户没有登陆
        print('用户还没有登陆!即将重定向!')
        return flask.redirect('/')
    insert_result = ''
    # 当用户登陆有存储信息时显示用户名,否则为空
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    # 获取显示管理员数据信息(GET方法的时候显示数据)
    if flask.request.method == 'GET':
        sql_list = "select * from students_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    if flask.request.method == 'POST':
        # 获取输入的学生信息
        student_id = flask.request.values.get("student_id", "")
        student_class = flask.request.values.get("student_class", "")
        student_name = flask.request.values.get("student_name", "")
        print(student_id, student_class, student_name)
        select_student = flask.request.form.get('student_operation')
        print("select operation = ",select_student)
        if select_student == '增加':
            try:
                # 信息存入数据库
                sql = "create table if not exists students_infos(student_id varchar(15),student_class varchar(20),student_name varchar(10),primary key(student_id));"
                cursor.execute(sql)
                sql_1 = "insert into students_infos(student_id, student_class, student_name) values (%s,%s,%s)"
                        # "select %s,%s,%s from students_decision_infos where %s not in (select student_id from students_decision_infos where student_class_id = %s and teacher_id = %s);"
                cursor.execute(sql_1, (student_id, student_class, student_name))
                # result = cursor.fetchone()
                insert_result = "成功存入一条学生信息，增加学生的学号为" + student_id
                print(insert_result)
            except Exception as err:
                print(err)
                insert_result = "学生信息插入失败"
                print(insert_result)
                pass
            db.commit()
        if select_student == '修改班级':
            sql_alter = "select student_id from students_infos where student_id = %s and student_name = %s;"
            cursor.execute(sql_alter, (student_id, student_name))
            student_result = cursor.fetchall()
            if student_result:
                try:
                    sql_alter = "update students_infos set student_class = %s where student_id = %s and student_name = %s;"
                    cursor.execute(sql_alter,(student_class,student_id,student_name))
                    insert_result = "修改班级成功，学号为" + student_id + "的学生" + student_name + "将班级修改为" + student_class
                except Exception as err:
                    print(err)
                    insert_result = "修改失败"
                    pass
                db.commit()
            else:
                print("未找到对应的学生")
                insert_result = "修改失败"
        if select_student == '修改姓名':
            sql_alter = "select student_id from students_infos where student_id = %s and student_class = %s;"
            cursor.execute(sql_alter, (student_id, student_class))
            student_result = cursor.fetchall()
            if student_result:
                try:
                    sql_alter = "update students_infos set student_name = %s where student_id = %s and student_class = %s;"
                    cursor.execute(sql_alter,(student_name,student_id,student_class))
                    insert_result = "成功将"+student_class+"的学号为" + student_id + "的学生姓名修改为" + student_name
                except Exception as err:
                    print(err)
                    insert_result = "修改失败"
                    pass
                db.commit()
            else:
                print("未找到对应的学生")
                insert_result = "修改失败"
        if select_student == '删除':
            sql_alter = "select student_id from students_infos where student_id = %s and student_class = %s and student_name = %s;"
            cursor.execute(sql_alter, (student_id, student_class, student_name))
            student_result = cursor.fetchall()
            if student_result:
                try:
                    sql_delete = "delete from students_infos where student_id = %s and student_class = %s and student_name = %s;"
                    cursor.execute(sql_delete,(student_id, student_class, student_name))
                    insert_result = "成功将"+student_class+"的学号为" + student_id + "姓名为" + student_name + "的学生信息删除"
                except Exception as err:
                    print(err)
                    insert_result = "删除失败"
                    pass
                db.commit()
            else:
                print("未找到对应的学生")
                insert_result = "删除失败"
        # POST方法时显示数据
        sql_list = "select * from students_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    return flask.render_template('student.html', insert_result=insert_result, user_info=user_info, results=results)


@app.route('/teacher', methods=['GET', "POST"])
def teacher():
    # login session值
    if flask.session.get("login", "") == '':
        # 用户没有登陆
        print('用户还没有登陆!即将重定向!')
        return flask.redirect('/')
    insert_result = ''
    # 当用户登陆有存储信息时显示用户名,否则为空
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    # 获取显示管理员数据信息(GET方法的时候显示数据)
    if flask.request.method == 'GET':
        sql_list = "select * from students_decision_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    if flask.request.method == 'POST':
        # 获取输入的学生选课信息
        student_id = flask.request.values.get("student_id", "")
        student_class_id = flask.request.values.get("student_class_id", "")
        teacher_id = flask.request.values.get("teacher_id", "")
        print(student_id, student_class_id, teacher_id)
        select_teacher = flask.request.form.get('teacher_operation')
        print("select operation = ",select_teacher)
        if select_teacher == '增加':
            try:
                # 信息存入数据库
                sql = "create table if not exists students_decision_infos(student_id varchar(15),student_class_id varchar(20),teacher_id varchar(15),primary key(student_id,student_class_id),foreign key(student_id) references students_infos(student_id));"
                cursor.execute(sql)
                sql_1 = "insert into students_decision_infos(student_id, student_class_id, teacher_id) values (%s,%s,%s)"
                        # "select %s,%s,%s from students_decision_infos where %s not in (select student_id from students_decision_infos where student_class_id = %s and teacher_id = %s);"
                cursor.execute(sql_1, (student_id, student_class_id, teacher_id))
                # result = cursor.fetchone()
                insert_result = "成功存入一条选课信息，增加学生的学号为" + student_id
                print(insert_result)
            except Exception as err:
                print(err)
                insert_result = "选课信息插入失败"
                print(insert_result)
                pass
            db.commit()
        if select_teacher == '修改教师号':
            sql_alter = "select student_id from students_decision_infos where student_id = %s and student_class_id = %s;"
            cursor.execute(sql_alter, (student_id, student_class_id))
            teacher_result = cursor.fetchall()
            if teacher_result:
                try:
                    sql_alter = "update students_decision_infos set teacher_id = %s where student_id = %s and student_class_id = %s;"
                    cursor.execute(sql_alter,(teacher_id,student_id,student_class_id))
                    insert_result = "修改课程号成功，学号为" + student_id + "的学生将课程号为" + student_class_id + "的课程教师号修改为" + teacher_id
                except Exception as err:
                    print(err)
                    insert_result = "修改失败"
                    pass
                db.commit()
            else:
                print("未找到对应的课程")
                insert_result = "修改失败"
        if select_teacher == '删除':
            sql_alter = "select student_id from students_decision_infos where student_id = %s and student_class_id = %s and teacher_id = %s;"
            cursor.execute(sql_alter, (student_id, student_class_id, teacher_id))
            teacher_result = cursor.fetchall()
            if teacher_result:
                try:
                    sql_delete = "delete from students_decision_infos where student_id = %s and student_class_id = %s and teacher_id = %s;"
                    cursor.execute(sql_delete,(student_id, student_class_id, teacher_id))
                    insert_result = "成功将学号为" + student_id + "课程号为" + student_class_id + "教师号为" + teacher_id + "的选课信息删除"
                except Exception as err:
                    print(err)
                    insert_result = "删除失败"
                    pass
                db.commit()
            else:
                print("未找到对应的课程")
                insert_result = "删除失败"
        # POST显示数据
        sql_list = "select * from students_decision_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    return flask.render_template('teacher.html', insert_result=insert_result, user_info=user_info, results=results)


@app.route('/grade', methods=['GET', "POST"])
def grade():
    # login session值
    if flask.session.get("login", "") == '':
        # 用户没有登陆
        print('用户还没有登陆!即将重定向!')
        return flask.redirect('/')
    insert_result = ''
    # 当用户登陆有存储信息时显示用户名,否则为空
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    # 获取显示管理员数据信息(GET方法的时候显示数据)
    if flask.request.method == 'GET':
        sql_list = "select * from grade_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    if flask.request.method == 'POST':
        # 获取输入的学生成绩信息
        student_id = flask.request.values.get("student_id", "")
        student_class_id = flask.request.values.get("student_class_id", "")
        grade = flask.request.values.get("grade", "")
        print(student_id, student_class_id, grade)
        select_grade = flask.request.form.get('grade_operation')
        print("select operation = ",select_grade)

        if select_grade == '增加':
            try:
                # 信息存入数据库
                sql = "create table if not exists grade_infos(student_id varchar(15),student_class_id varchar(20),grade varchar(15),primary key(student_id,student_class_id),foreign key(student_id,student_class_id) references students_decision_infos(student_id,student_class_id));"
                cursor.execute(sql)
                sql_1 = "insert into grade_infos(student_id, student_class_id, grade) values(%s,%s,%s);"
                cursor.execute(sql_1, (student_id, student_class_id, grade))
                # result = cursor.fetchone()
                insert_result = "成功存入一条成绩信息，增加学生的学号为" + student_id + "课程号为" + student_class_id
                print(insert_result)
            except Exception as err:
                print(err)
                insert_result = "成绩信息插入失败"
                print(insert_result)
                pass
            db.commit()
        if select_grade == '修改课程号':
            sql_alter = "select student_id from grade_infos where student_id = %s and grade = %s;"
            cursor.execute(sql_alter, (student_id, grade))
            grade_result = cursor.fetchall()
            if grade_result:
                try:
                    sql_alter = "update grade_infos set student_class_id = %s where student_id = %s and grade = %s;"
                    cursor.execute(sql_alter,(student_class_id,student_id,grade))
                    insert_result = "修改课程号成功，学号为" + student_id + "的学生将成绩为" + grade + "的课程课程号修改为" + student_class_id
                except Exception as err:
                    print(err)
                    insert_result = "修改失败"
                    pass
                db.commit()
            else:
                print("未找到对应的课程")
                insert_result = "修改失败"
        if select_grade == '修改成绩':
            sql_alter = "select student_id from grade_infos where student_id = %s and student_class_id = %s;"
            cursor.execute(sql_alter, (student_id, student_class_id))
            grade_result = cursor.fetchall()
            if grade_result:
                try:
                    sql_alter = "update grade_infos set grade = %s where student_id = %s and student_class_id = %s;"
                    cursor.execute(sql_alter,(grade,student_id,student_class_id))
                    insert_result = "修改课程号成功，学号为" + student_id + "的学生将课程号为" + student_class_id + "的课程成绩修改为" + grade
                except Exception as err:
                    print(err)
                    insert_result = "修改失败"
                    pass
                db.commit()
            else:
                print("未找到对应的课程")
                insert_result = "修改失败"
        if select_grade == '删除':
            sql_alter = "select student_id from grade_infos where student_id = %s and student_class_id = %s and grade = %s;"
            cursor.execute(sql_alter, (student_id, student_class_id, grade))
            grade_result = cursor.fetchall()
            if grade_result:
                try:
                    sql_delete = "delete from grade_infos where student_id = %s and student_class_id = %s and grade = %s;"
                    cursor.execute(sql_delete,(student_id, student_class_id, grade))
                    insert_result = "成功将学号为" + student_id + "课程号为" + student_class_id + "教师号为" + grade + "的选课信息删除"
                except Exception as err:
                    print(err)
                    insert_result = "删除失败"
                    pass
                db.commit()
            else:
                print("未找到对应的课程")
                insert_result = "删除失败"
        # POST获取数据
        sql_list = "select * from grade_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    return flask.render_template('grade.html', insert_result=insert_result, user_info=user_info, results=results)


@app.route('/grade_infos', methods=['GET', 'POST'])
def grade_infos():
    # login session值
    if flask.session.get("login", "") == '':
        # 用户没有登陆
        print('用户还没有登陆!即将重定向!')
        return flask.redirect('/')
    query_result = ''
    results = ''
    # 当用户登陆有存储信息时显示用户名,否则为空
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    # 获取下拉框的数据
    if flask.request.method == 'POST':
        select = flask.request.form.get('selected_one')
        query = flask.request.values.get('query')
        print(select, query)
        # 判断不同输入对数据表进行不同的处理
        if select == '学号':
            try:
                sql = "select * from grade_infos where student_id = %s; "
                cursor.execute(sql, query)
                results = cursor.fetchall()
                if results:
                    query_result = '查询成功!'
                else:
                    query_result = '查询失败!'
            except Exception as err:
                print(err)
                pass
        if select == '姓名':
            try:
                sql = "select * from grade_infos where student_id in(select student_id from students_infos where student_name=%s);"
                cursor.execute(sql, query)
                results = cursor.fetchall()
                if results:
                    query_result = '查询成功!'
                else:
                    query_result = '查询失败!'
            except Exception as err:
                print(err)
                pass

        if select == '课程号':
            try:
                sql = "select * from grade_infos where student_class_id in(select student_class_id from students_infos where student_class_id=%s);"
                cursor.execute(sql, query)
                results = cursor.fetchall()
                if results:
                    query_result = '查询成功!'
                else:
                    query_result = '查询失败!'
            except Exception as err:
                print(err)
                pass

        if select == "所在班级":
            try:
                sql = "select * from grade_infos where student_class_id in(select student_class_id from students_infos where student_class=%s);"
                cursor.execute(sql, query)
                results = cursor.fetchall()
                if results:
                    query_result = '查询成功!'
                else:
                    query_result = '查询失败!'
            except Exception as err:
                print(err)
                pass
    return flask.render_template('grade_infos.html', query_result=query_result, user_info=user_info, results=results)


@app.route('/adminstator', methods=['GET', "POST"])
def adminstator():
    # login session值
    if flask.session.get("login", "") == '':
        # 用户没有登陆
        print('用户还没有登陆!即将重定向!')
        return flask.redirect('/')
    insert_result = ''
    # 获取显示管理员数据信息(GET方法的时候显示数据)
    if flask.request.method == 'GET':
        sql_list = "select * from admins"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    # 当用户登陆有存储信息时显示用户名,否则为空
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    if flask.request.method == 'POST':
        # 获取输入的管理员信息
        admin_name = flask.request.values.get("admin_name", "")
        admin_password = flask.request.values.get("admin_password", "")
        admin_authority = flask.request.values.get("select_admin_authority", "")
        admin_name_result = re.search(r"^[a-zA-Z]+$", admin_name)  # 限制用户名为全字母
        admin_password_result = re.search(r"^[a-zA-Z\d]+$", admin_password)  # 限制密码为 字母和数字的组合
        # 验证通过
        if admin_name_result != None:  # 验证通过
            # 获取下拉框的数据
            select = flask.request.form.get('admin_operation')
            admin_password_hash = hashlib.md5(admin_password.encode('UTF-8')).hexdigest() #对用户密码md5加密
            if select == '增加用户' and admin_password_result != None:
                try:
                    """sql = "create table if not exists admins(admin_name varchar(15),admin_password varchar(50),admin_authority varchar(45),primary key(admin_name));"
                    cursor.execute(sql)"""
                    sql_add = "insert into admins(admin_name,admin_password,admin_authority)values(%s,%s,%s);"
                    cursor.execute(sql_add,(admin_name,admin_password_hash,admin_authority))
                    insert_result = "成功增加了一名用户"
                    print(insert_result)
                except Exception as err:
                    print(err)
                    insert_result = "增加用户操作失败"
                    print(insert_result)
                    pass
                db.commit()
            if select == '修改密码':
                sql_alter = "select admin_name from admins where admin_name = %s and admin_authority = %s;"
                cursor.execute(sql_alter, (admin_name, admin_authority))
                admin_result = cursor.fetchall()
                if admin_result:
                    try:
                        sql_alter = "update admins set admin_password=%s where admin_name=%s;"
                        cursor.execute(sql_alter, (admin_password_hash, admin_name))
                        insert_result = "用户" + admin_name + "的密码修改成功!"
                    except Exception as err:
                        print(err)
                        insert_result = "修改用户密码失败!"
                        pass
                    db.commit()
                else:
                    print("未找到对应的用户")
                    insert_result = "修改失败"
            if select == '修改权限':
                sql_alter = "select admin_name from admins where admin_name = %s and admin_password = %s;"
                cursor.execute(sql_alter, (admin_name, admin_password_hash))
                admin_result = cursor.fetchall()
                if admin_result:
                    try:
                        sql_alter = "update admins set admin_authority=%s where admin_name=%s;"
                        cursor.execute(sql_alter, (admin_authority, admin_name))
                        insert_result = admin_name + "的权限修改成功!"
                    except Exception as err:
                        print(err)
                        insert_result = "修改用户权限失败!"
                        pass
                    db.commit()
                else:
                    print("未找到对应的用户")
                    insert_result = "修改失败"
            if select == '删除用户' and admin_name != 'admin':
                sql_alter = "select admin_name from admins where admin_name = %s and admin_password = %s and admin_authority = %s;"
                cursor.execute(sql_alter, (admin_name, admin_password_hash, admin_authority))
                admin_result = cursor.fetchall()
                if admin_result:
                    try:
                        sql_delete = "delete from admins where admin_name='" + admin_name + "';"
                        cursor.execute(sql_delete)
                        insert_result = "成功删除用户" + admin_name
                    except Exception as err:
                        print(err)
                        insert_result = "删除用户失败"
                        pass
                    db.commit()
                else:
                    print("未找到对应的用户")
                    insert_result = "删除失败"
        else:  # 输入验证不通过
            insert_result = "输入的格式或用户不符合要求!"
        # POST方法时显示数据
        sql_list = "select * from admins"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    return flask.render_template('adminstator.html', user_info=user_info, insert_result=insert_result, results=results)


@app.route('/backup', methods=['GET', "POST"])
def backup():
    # login session值
    if flask.session.get("login", "") == '':
        # 用户没有登陆
        print('用户还没有登陆!即将重定向!')
        return flask.redirect('/')
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''

    if flask.request.method == 'POST':
        if flask.request.form.get('backup') == '数据备份':
            try:
                print("进行数据备份")
                sql_backup = "mysqldump -udawn -p123qweasd db4 > /home/dawn/database/program4/backup/db4_backup.sql"
                db.close()
                os.system(sql_backup)
                db.connect()
            except Exception as err:
                print(err)
                pass
        elif flask.request.form.get('recovery') == '数据恢复':
            try:
                print("进行数据恢复")
                sql_recovery = "mysql -udawn -p123qweasd db4 < /home/dawn/database/program4/backup/db4_backup.sql"
                db.close()
                os.system(sql_recovery)
                db.connect()
            except Exception as err:
                print(err)
                pass
        else:
            pass
    else:
        print("post deny")
    return flask.render_template('backup.html', user_info=user_info)


app.debug = True

if __name__ == '__main__':
    try:
        app.run()
    except Exception as err:
        print(err)
        db.close()  # 关闭数据库连接