-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: db4
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `admin_name` varchar(15) NOT NULL,
  `admin_password` varchar(50) DEFAULT NULL,
  `admin_authority` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`admin_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES ('admin','123qweasd','管理员'),('chr','57ba172a6be125cca2f449826f9980ca','学生'),('czh','57ba172a6be125cca2f449826f9980ca','教师'),('jch','57ba172a6be125cca2f449826f9980ca','学生'),('test','57ba172a6be125cca2f449826f9980ca','学生'),('ym','57ba172a6be125cca2f449826f9980ca','教师'),('ys','57ba172a6be125cca2f449826f9980ca','学生');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_infos`
--

DROP TABLE IF EXISTS `grade_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grade_infos` (
  `student_id` varchar(15) NOT NULL,
  `student_class_id` varchar(20) NOT NULL,
  `grade` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`student_id`,`student_class_id`),
  CONSTRAINT `grade_infos_ibfk_1` FOREIGN KEY (`student_id`, `student_class_id`) REFERENCES `students_decision_infos` (`student_id`, `student_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade_infos`
--

LOCK TABLES `grade_infos` WRITE;
/*!40000 ALTER TABLE `grade_infos` DISABLE KEYS */;
INSERT INTO `grade_infos` VALUES ('2020302181047','1','90'),('2020302181047','2','91'),('2020302181047','3','92'),('2020302181051','1','91'),('2020302181051','2','93'),('2020302181079','1','92'),('2020302181080','1','95');
/*!40000 ALTER TABLE `grade_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students_decision_infos`
--

DROP TABLE IF EXISTS `students_decision_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students_decision_infos` (
  `student_id` varchar(15) NOT NULL,
  `student_class_id` varchar(20) NOT NULL,
  `teacher_id` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`student_id`,`student_class_id`),
  CONSTRAINT `students_decision_infos_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students_infos` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students_decision_infos`
--

LOCK TABLES `students_decision_infos` WRITE;
/*!40000 ALTER TABLE `students_decision_infos` DISABLE KEYS */;
INSERT INTO `students_decision_infos` VALUES ('2020302181047','1','1'),('2020302181047','2','2'),('2020302181047','3','3'),('2020302181051','1','4'),('2020302181051','2','2'),('2020302181079','1','1'),('2020302181080','1','1'),('2020302181081','3','5'),('2020302181082','3','3');
/*!40000 ALTER TABLE `students_decision_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students_infos`
--

DROP TABLE IF EXISTS `students_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students_infos` (
  `student_id` varchar(15) NOT NULL,
  `student_class` varchar(45) DEFAULT NULL,
  `student_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students_infos`
--

LOCK TABLES `students_infos` WRITE;
/*!40000 ALTER TABLE `students_infos` DISABLE KEYS */;
INSERT INTO `students_infos` VALUES ('2020302181047','20-2','严石'),('2020302181051','20-2','靳晨浩'),('2020302181062','20-2','崔浩然'),('2020302181079','20-3','赵某'),('2020302181080','20-3','钱某'),('2020302181081','20-4','孙某'),('2020302181082','20-4','李某');
/*!40000 ALTER TABLE `students_infos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-29 19:22:51
