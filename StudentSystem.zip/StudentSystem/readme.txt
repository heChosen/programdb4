HTML		功能
student 	学生信息录入
teacher	选课信息录入
grade		成绩信息录入
grade_infos	学生成绩查询
adminstator	系统管理员变动
backup		数据备份与恢复界面
findCrpto	找回密码界面
resetcrpto	重置密码界面

权限管理：
student、teacher、grade 教师操作界面
grade_infos 学生操作界面
adminstator、backup 管理员操作界面

主键及外键：
CREATE TABLE `admins` (
  `admin_name` varchar(15) NOT NULL,
  `admin_password` varchar(50) DEFAULT NULL,
  `admin_authority` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`admin_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `grade_infos` (
  `student_id` varchar(15) NOT NULL,
  `student_class_id` varchar(20) NOT NULL,
  `grade` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`student_id`,`student_class_id`),
  CONSTRAINT `grade_infos_ibfk_1` FOREIGN KEY (`student_id`, `student_class_id`) REFERENCES `students_decision_infos` (`student_id`, `student_class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `students_decision_infos` (
  `student_id` varchar(15) NOT NULL,
  `student_class_id` varchar(20) NOT NULL,
  `teacher_id` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`student_id`,`student_class_id`),
  CONSTRAINT `students_decision_infos_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students_infos` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `students_infos` (
  `student_id` varchar(15) NOT NULL,
  `student_class` varchar(45) DEFAULT NULL,
  `student_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
